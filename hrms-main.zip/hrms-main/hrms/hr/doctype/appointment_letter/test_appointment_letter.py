# Copyright (c) 2019, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
import unittest


class TestAppointmentLetter(unittest.TestCase):
	pass
