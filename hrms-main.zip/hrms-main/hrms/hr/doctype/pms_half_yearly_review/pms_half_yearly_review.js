frappe.ui.form.on('PMS Half Yearly Review', {

	onload: function(frm) {	
		// To hide Add Row button under each child Table
		frm.fields_dict['financial_perspective'].grid.cannot_add_rows = true;		
		frm.fields_dict['customer_perspective'].grid.cannot_add_rows = true;
		frm.fields_dict['internal_process'].grid.cannot_add_rows = true;
		frm.fields_dict['learning_and_growth'].grid.cannot_add_rows = true;
		frm.fields_dict['special_assignments__projects'].grid.cannot_add_rows = true;

        // Define editable fields for each child table
        $.each(["financial_perspective", "customer_perspective", "internal_process", "learning_and_growth", "special_assignments__projects"], function(i, table_fieldname) {
            frm.get_field(table_fieldname).grid.editable_fields = [
                {fieldname: 'kra', columns: 3},
                {fieldname: 'kpi_title', columns: 3},
                {fieldname: 'half_yearly_report', columns: 3},
                {fieldname: 'half_yearly_review', columns: 3},
            ];
        });
		 
    },

	before_submit: function(frm) {
        // Loop through each child table to check mandatory fields
        function check_mandatory_fields(child_table_name, mandatory_fields) {
            $.each(frm.doc[child_table_name] || [], function(i, row) {
                mandatory_fields.forEach(function(field) {
                    if (!row[field]) {
                        frappe.throw(__('Row #{0} of {1}:  Half Yearly Review Review - {2} is mandatory.', [(i+1), child_table_name, frappe.meta.get_label(row.doctype, field)]));
                    }
                });
            });
        }

        // Check mandatory fields for each child table
        check_mandatory_fields("financial_perspective", ["half_yearly_report", "half_yearly_review"]);
        check_mandatory_fields("customer_perspective", ["half_yearly_report", "half_yearly_review"]);
        check_mandatory_fields("internal_process", ["half_yearly_report", "half_yearly_review"]);
        check_mandatory_fields("learning_and_growth", ["half_yearly_report", "half_yearly_review"]);
        check_mandatory_fields("special_assignments__projects", ["half_yearly_report", "half_yearly_review"]);
    },

    setup: function(frm) {
		frm.set_query("employee", erpnext.queries.employee);
	},

	employee: function(frm){
		if(frm.doc.docstatus == 0){
			frm.trigger('request_action')
            frm.events.create_new_doc(frm)
		}
	},

    pms_period:function(frm){
        frm.events.create_new_doc(frm)
    },


    refresh: function(frm) {

        // Function to loop through each child table and set properties
        // Approach: Targets the specific newly added row in the child table and hides the field 
        // only for that row (frappe.meta.get_docfield("PMS Details", "half_yearly_review_section", row.name).hidden = 1;).
       
        function set_properties_for_child(child_table_name) {
            $.each(frm.doc[child_table_name] || [], function(i, row) {
                frappe.meta.get_docfield("PMS Details", "area", row.name).read_only = 1;
                frappe.meta.get_docfield("PMS Details", "kra", row.name).read_only = 1;
                frappe.meta.get_docfield("PMS Details", "kpi_title", row.name).read_only = 1;
                frappe.meta.get_docfield("PMS Details", "kpi_description", row.name).read_only = 1;
                frappe.meta.get_docfield("PMS Details", "date", row.name).read_only = 1;
                // frappe.meta.get_docfield("PMS Details", "half_yearly_review_section", row.name).hidden = 0;
                // frappe.meta.get_docfield("PMS Details", "half_yearly_review", row.name).read_only = 0;
                // frappe.meta.get_docfield("PMS Details", "half_yearly_report", row.name).read_only = 0;
                frappe.meta.get_docfield("PMS Details", "annual_review_section", row.name).hidden = 1;
            });
        }

        // Apply the properties for each child table
        set_properties_for_child("financial_perspective");
        set_properties_for_child("customer_perspective");
        set_properties_for_child("internal_process");
        set_properties_for_child("learning_and_growth");
        set_properties_for_child("special_assignments__projects");

        // Refresh the child tables to apply the changes
        frm.refresh_field("financial_perspective");
        frm.refresh_field("customer_perspective");
        frm.refresh_field("internal_process");
        frm.refresh_field("learning_and_growth");
        frm.refresh_field("special_assignments__projects");

        
        // ***************** Custom Button ***************//

		// if doc has all proper show button on the top to create next level process
		if((frm.doc.docstatus == 1) && ["Approved by HR", "Approved by Reporting Incharge", "Approved by HOD", "Approved by CHO"].includes(frm.doc.status)){
			frm.add_custom_button(__('Create Annual Review'), function() {	
				
				frappe.call({
					method: "hrms.hr.doctype.pms_half_yearly_review.pms_half_yearly_review.check_existing_document",
					args: {
						employee : frm.doc.employee,
						pms_period : frm.doc.pms_period,
                        doc_type :  "PMS Annual Review"
					},
					callback: function(r1) {
						if (r1.message) {
							frappe.set_route("Form", "PMS Annual Review", r1.message);
						} else {                        
                            // Create a new document with 
							frappe.new_doc("PMS Annual Review",{
								employee : frm.doc.employee,
								pms_period : frm.doc.pms_period,
                                doc_type : "PMS Annual Review"
							},doc =>{
								// doc.employee = frm.doc.employee,
								// doc.pms_period = frm.doc.pms_period
								return frappe.set_route("Form", "PMS Annual Review", doc.name);
							})
							
                            
						}
					}
				});
			});
		}


		// check whether approver has right to Approve Approval
        var isApprover = frm.doc.approver === frappe.user.name || frm.doc.hod_approver === frappe.user.name || frm.doc.cho_approver === frappe.user.name;
		
		// Set status options based on user role and fields in the employee document
		//frappe.user_roles variable is used in Frappe to retrieve the list of roles assigned 
		// to the currently logged-in user. It returns an array of role names.
		var user_roles = frappe.user_roles;
		//if HR Manager/HR user creates records for the employee they can directly approvers
		var hasRolePermission = user_roles.includes("HR Manager") || user_roles.includes("HR User");


		console.log("user_roles--",user_roles)
		console.log("isApprover --",isApprover)
		console.log("hasRolePermission--",hasRolePermission)
		console.log("frappe.session.user--",frappe.session.user)
		console.log("frappe.user.name--",frappe.user.name)
		console.log("frm.doc.reporting_incharge--",frm.doc.approver)
		console.log("frm.doc.hod_approver--",frm.doc.hod_approver)

        if (isApprover || hasRolePermission) {
			// if doc is in the first stage of Approval Don't show any Request Actions for any Approver Default will be Draft
			if(!frm.doc.reporting_incharge_status && !frm.doc.hod_approver_status && !frm.doc.cho_approver_status){
				// Hide Request Action field
				frm.set_df_property("request_action", "hidden", true);
			}else{
				// Show Request Action field for approvers with Approved and Rejected options
				frm.set_df_property("request_action", "hidden", false);
				frm.set_df_property("request_action", "options", ["Approved", "Rejected"]);
			}

			console.log("!frm.doc.hod_approver--",!frm.doc.reporting_incharge_status && !frm.doc.hod_approver_status)
        } else{
			// Hide Request Action field for non-approvers
            frm.set_df_property("request_action", "hidden", true);
		}
		
		if(frm.doc.docstatus == 0){
			frm.trigger('request_action')
		}
    },
	request_action:function(frm){
		console.log("frm.doc.status---",frm.doc.status)
		console.log("frm.doc.request_action---",frm.doc.request_action)

		// check whether approver has right to Approve Approval
        var isApprover = frm.doc.approver === frappe.user.name || frm.doc.hod_approver === frappe.user.name || frm.doc.cho_approver === frappe.user.name;
		
		// Set status options based on user role and fields in the employee document
		//frappe.user_roles variable is used in Frappe to retrieve the list of roles assigned 
		// to the currently logged-in user. It returns an array of role names.
		var user_roles = frappe.user_roles;
		//if HR Manager/HR user creates records for the employee they can directly approvers
		var hasRolePermission = user_roles.includes("HR Manager") || user_roles.includes("HR User");

		// after proper Request action is selected 

		if(frm.doc.request_action == "Approved" && (isApprover || hasRolePermission)){
			if(frm.doc.employee){
				// if Reporting Incharge Exists and Reporting Incharge is the current Approver
				if(frm.doc.approver && frm.doc.approver === frappe.user.name){ // if Reporting Incharge Exists
					//if HOD Exists 
					if(frm.doc.hod_approver){

						frm.set_value('status',"Awaiting HOD Approval")
						frm.set_value("reporting_incharge_status","Approved by Reporting Incharge")
						frm.set_value("hod_approver_status","Awaiting HOD Approval")
						frm.set_value("cho_approver_status","")
						refresh_field('status')
						refresh_field('reporting_incharge_status')
						refresh_field('hod_approver_status')
						refresh_field('cho_approver_status')
						
					}
					// if HOD Doesn't Exists - Reporting Incharge is doing Final Approval 
					else{

						frm.set_value("status","Approved by Reporting Incharge")
						frm.set_value("reporting_incharge_status","Approved by Reporting Incharge")
						frm.set_value("hod_approver_status","")
						frm.set_value("cho_approver_status","")
						refresh_field('status')
						refresh_field('reporting_incharge_status')
						refresh_field('hod_approver_status')						
						refresh_field('cho_approver_status')
					}
				}
				
				// if HOD Exists and HOD is the current Approver then HOD will be the Final Approver

				else if(frm.doc.hod_approver && frm.doc.hod_approver == frappe.user.name){ // if Reporting Incharge Doesn't Exists
					
					// if HOD Exists										
						frm.set_value('status',"Approved by HOD")
						frm.set_value("hod_approver_status","Approved by HOD")
						refresh_field('status')
						refresh_field('hod_approver_status')
					
				}
				
				// if CHO Exists and CHO is the current Approver then CHO will be the Final Approver

				else if (frm.doc.cho_approver && frm.doc.cho_approver == frappe.user.name){ // if CHO Exists
					
						frm.set_value('status',"Approved by CHO")
						frm.set_value("cho_approver_status","Approved by CHO")
						refresh_field('status')
						refresh_field('cho_approver_status')

				}
				
				else if (hasRolePermission){
					frm.set_value('status',"Approved by HR")
					refresh_field('status')
				}
				
				else{
					frappe.throw("You are not allowed to Approve!");
				}
			}
		}
		
		else if(frm.doc.request_action == "Rejected"  && (isApprover || hasRolePermission)){
			if(frm.doc.employee){
				// if Reporting Incharge Exists and Reporting Incharge is the current Approver
				if(frm.doc.approver && frm.doc.approver === frappe.user.name){ // if Reporting Incharge Exists

					frm.set_value('status',"Rejected by Reporting Incharge")
					frm.set_value("reporting_incharge_status","Rejected by Reporting Incharge")
					frm.set_value("hod_approver_status","")
					frm.set_value("cho_approver_status","")
					refresh_field('status')
					refresh_field('reporting_incharge_status')
					refresh_field('hod_approver_status')
					refresh_field('cho_approver_status')

				}
				
				// if HOD Exists and HOD is the current Approver then HOD will be the Final Approver

				else if(frm.doc.hod_approver && frm.doc.hod_approver == frappe.user.name){ // if Reporting Incharge Doesn't Exists
					
					// if HOD Exists										
					frm.set_value('status',"Rejected by HOD")
					frm.set_value("hod_approver_status","Rejected by HOD")
					refresh_field('status')
					refresh_field('hod_approver_status')
					
				}
				
				// if CHO Exists and CHO is the current Approver then CHO will be the Final Approver

				else if (frm.doc.cho_approver && frm.doc.cho_approver == frappe.user.name){ // if CHO Exists
					
					frm.set_value('status',"Rejected by CHO")
					frm.set_value("cho_approver_status","Rejected by CHO")
					refresh_field('status')
					refresh_field('cho_approver_status')

				}
				
				else if (hasRolePermission){
					frm.set_value('status',"Rejected by HR")
					refresh_field('status')
				}
				
				else{
					frappe.throw("You are not allowed to Reject!");
				}
			}
			
		}
				
		else if(frm.doc.request_action == "Draft"){

			if(frm.doc.employee){

				if(frm.doc.approver){ // if Reporting Incharge Exists
					frm.set_value('status',"Awaiting Reporting Incharge Approval")
					frm.set_value("reporting_incharge_status","Awaiting Reporting Incharge Approval")
					frm.set_value("hod_approver_status","")
					frm.set_value("cho_approver_status","")
					refresh_field('status')
					refresh_field('reporting_incharge_status')
					refresh_field('hod_approver_status')
					refresh_field('cho_approver_status')
				}else if (!frm.doc.approver){ // if Reporting Incharge Doesn't Exists
					if(frm.doc.hod_approver){ // if HOD Exists
						frm.set_value('status',"Awaiting HOD Approval")
						frm.set_value("reporting_incharge_status","")
						frm.set_value("hod_approver_status","Awaiting HOD Approval")
						refresh_field('status')
						refresh_field('reporting_incharge_status')
						refresh_field('hod_approver_status')
						refresh_field('cho_approver_status')
					}else if (frm.doc.cho_approver){ // if CHO Exists
						frm.set_value('status',"Awaiting CHO Approval")
						frm.set_value("reporting_incharge_status","")
						frm.set_value("hod_approver_status","")
						frm.set_value("cho_approver_status","Awaiting CHO Approval")
						refresh_field('status')
						refresh_field('reporting_incharge_status')
						refresh_field('hod_approver_status')
						refresh_field('cho_approver_status')
					}
					else{
						// frappe.throw("No Approvers Found!");
					}
				}
				else{
					// frappe.throw("No Approvers Found!");
				}
			}
		}

	},

    create_new_doc:function(frm) {
        // Create a new document with previous stage details 
        // so first check for previous stage details ,nothing exists throw error
        if(frm.doc.employee && frm.doc.pms_period){

            // First, clear existing child tables
            frm.doc.financial_perspective = [];
            frm.doc.customer_perspective = [];
            frm.doc.internal_process = [];
            frm.doc.learning_and_growth = [];
            frm.doc.special_assignments__projects = [];

            frm.refresh_field('financial_perspective');
            frm.refresh_field('customer_perspective');
            frm.refresh_field('internal_process');
            frm.refresh_field('learning_and_growth');
            frm.refresh_field('special_assignments__projects');


            // Get previous stage records ---- 
            frappe.call({
                method: "hrms.hr.doctype.pms_targets.pms_targets.check_previous_stage_existing_document",
                args: {
                    employee : frm.doc.employee,
                    pms_period : frm.doc.pms_period,
                    doc_type :  "PMS Targets",                
                },
                callback: function(r1) {
                    if (r1.message) {
                        // Fetch the document
                        frappe.db.get_doc('PMS Targets', r1.message)
                            .then(doc => {

                                // First, clear existing child tables
                                frm.doc.financial_perspective = [];
                                frm.doc.customer_perspective = [];
                                frm.doc.internal_process = [];
                                frm.doc.learning_and_growth = [];
                                frm.doc.special_assignments__projects = [];

                                frm.refresh_field('financial_perspective');
                                frm.refresh_field('customer_perspective');
                                frm.refresh_field('internal_process');
                                frm.refresh_field('learning_and_growth');
                                frm.refresh_field('special_assignments__projects');


                                // Loop through each child table and add records
                                ["financial_perspective", "customer_perspective", "internal_process", "learning_and_growth", "special_assignments__projects"].forEach(field => {
                                    doc[field].forEach(d => {

                                        var row = frappe.model.add_child(frm.doc, "PMS Details", field);
                                        Object.assign(row, d);
                                    });

                                    // Refresh the child tables to reflect changes
                                    frm.refresh_field(field)
                                });

                            });
                    } else {
                        frappe.throw("No existing PMS Targets found for the selected Employee and PMS Period.");
                    }
                }
            })
        }
    },

});


