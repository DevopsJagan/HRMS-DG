// Add a custom button to the list view
frappe.listview_settings['Shift Assignment'] = {
    onload: function(list_view) {

        // Add a custom button to the list view
		list_view.page.add_inner_button(__('View Calendar'), function() {
		    // Get the logged-in user's ID
		    var user_id = frappe.session.user;
		
		    // Check if the user is not "Administrator" or "Guest"
		    if (user_id !== "Administrator") {
		        // Fetch the Employee ID linked to the user
		        frappe.db.get_value('Employee', {'user_id': user_id}, 'name', function(r) {
		            if (r && r.name) {
		                // Redirect to the calendar view with the fetched employee ID
		                frappe.set_route('List', 'Shift Assignment', 'Calendar', {employee: r.name});
		            } else {
		                frappe.msgprint(__("No linked Employee record found for the user: {0}", [user_id]));
		            }
		        });
		    } else {
				frappe.set_route('List', 'Shift Assignment', 'Calendar');
		    }
		});
    }
};
