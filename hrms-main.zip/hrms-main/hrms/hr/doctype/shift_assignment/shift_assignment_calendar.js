// Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and contributors
// For license information, please see license.txt

// frappe.views.calendar["Shift Assignment"] = {
// 	field_map: {
// 		"start": "start_date",
// 		"end": "end_date",
// 		"id": "name",
// 		"docstatus": 1,
// 		"allDay": "allDay",
// 		"convertToUserTz": "convertToUserTz",
// 	},
// 	// get_events_method: "hrms.hr.doctype.shift_assignment.shift_assignment.get_events"
// 	get_events_method: "hrms.hr.doctype.shift_assignment.shift_assignment.glovis_get_events"
// }


frappe.views.calendar["Shift Assignment"] = {
    
    make_page() {
        var me = this;

        // side 3 dots menu items 
        // if uncomment it will show Event,Leave Application, ...
    
        // // add links to other calendars
        // me.page.clear_user_actions();
        // $.each(frappe.boot.calendars, function (i, doctype) {
        //     if (frappe.model.can_read(doctype)) {
        //         me.page.add_menu_item(__(doctype), function () {
        //             frappe.set_route("List", doctype, "Calendar");
        //         });
        //     }
        // });
    
        // Add custom 3 dots menu button top corner
        if (me.page) {
            me.page.add_menu_item(__('List View'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Shift Assignment");
            });
			me.page.add_menu_item(__('Shift Request Application'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Shift Request");
            });
        }
    
        $(this.parent).on("show", function () {
            me.$cal.fullCalendar("refetchEvents");
        });
    },

    field_map: {
		"start": "start_date",
		"end": "end_date",
		// "id": "name",
		"title": "title",
	},
	options: {
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month'
		},

        // Disable selectable and editable to prevent creating new events
        selectable: false,
        editable: false,

        // Disable dayClick to prevent opening timeblocks
        dayClick: function(date, jsEvent, view) {
            // You can leave this function empty or add custom behavior if needed
        },

        // Disable eventClick to prevent redirection
        eventClick: function(calEvent, jsEvent, view) {
            // You can leave this function empty or add custom behavior if needed

            // // Check if the event has a specific event_name or other criteria
            // if (calEvent.event_name === 'E1' && (calEvent.title === 'Missed Punch' || calEvent.title === 'Permission')) {

            //     frappe.new_doc("Attendance Application", {
            //     //    employee : calEvent.employee
            //     }, doc => {
            //         doc.employee = calEvent.employee
            //         doc.date = calEvent.attendance_date
            //     });
            // }
        }
	},
    get_events_method:"hrms.hr.doctype.shift_assignment.shift_assignment.glovis_get_events",
    filters: [
        {
            fieldname: "employee",
            label: __("Employee"),
            fieldtype: "Link",
            options: "Employee",
            get_query: function() {
                return {
                    filters: [
                        ["Employee", "user_id", "=", frappe.user.name] // Show only the logged-in user's employee record
                    ]
                };
            }
        }
    ],
    // get_css_class: function(event) {
    //     // Define a color based on the status
    //     var shift = event.title.toLowerCase();

    //     if(event.event_name == 'E1'){
    //         if (shift === "gs") {
    //             return "success";
    //         } else if (shift === "a") {
    //             return "danger";
    //         } else if (shift === "b") {
    //             return "warning";
    //         }else if (shift === "c") {
    //             return "standard";
    //         }
    //     }else{
    //         return "info"
    //     }
    // }
};
