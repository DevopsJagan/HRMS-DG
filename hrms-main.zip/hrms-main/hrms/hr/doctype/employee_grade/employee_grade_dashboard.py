def get_data():
	return {
		"transactions": [
			{
				"items": ["Employee", "Leave Period"],
			},
			{"items": ["Employee Onboarding Template", "Employee Separation Template"]},
		]
	}
