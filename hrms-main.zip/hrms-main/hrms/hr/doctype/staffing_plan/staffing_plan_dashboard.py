def get_data():
	return {
		"fieldname": "staffing_plan",
		"transactions": [{"items": ["Job Opening"]}],
	}
