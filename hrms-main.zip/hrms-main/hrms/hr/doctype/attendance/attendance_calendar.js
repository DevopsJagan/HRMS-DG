frappe.views.calendar["Attendance"] = {
    
    make_page() {
        var me = this;

        // side 3 dots menu items 
        // if uncomment it will show Event,Leave Application, ...
    
        // // add links to other calendars
        // me.page.clear_user_actions();
        // $.each(frappe.boot.calendars, function (i, doctype) {
        //     if (frappe.model.can_read(doctype)) {
        //         me.page.add_menu_item(__(doctype), function () {
        //             frappe.set_route("List", doctype, "Calendar");
        //         });
        //     }
        // });
    
        // Add custom 3 dots menu button top corner
        if (me.page) {
            me.page.add_menu_item(__('List View'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Attendance");
            });
            me.page.add_menu_item(__('On Duty Application'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "On Duty Application");
            });
            me.page.add_menu_item(__('Missed Punch/Permission Application'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Attendance Application");
            });
            me.page.add_menu_item(__('Leave Application'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Leave Application");
            });
            me.page.add_menu_item(__('Compensatory Leave Request'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Compensatory Leave Request");
            });
            me.page.add_menu_item(__('Over Time Application'), function() {
                // Your button's action here, for example:
                frappe.set_route("List", "Over Time Application");
            });
        }
    
        $(this.parent).on("show", function () {
            me.$cal.fullCalendar("refetchEvents");
        });
    },

    field_map: {
		"start": "start",
		"end": "end",
		// "id": "name",
		"title": "title",
		"color": "color"
	},
	options: {
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month'
		},

        // Disable selectable and editable to prevent creating new events
        selectable: false,
        editable: false,

        // Disable dayClick to prevent opening timeblocks
        dayClick: function(date, jsEvent, view) {
            // You can leave this function empty or add custom behavior if needed
        },

        // Disable eventClick to prevent redirection
        eventClick: function(calEvent, jsEvent, view) {
            // You can leave this function empty or add custom behavior if needed

            // Check if the event has a specific event_name or other criteria
            if (calEvent.event_name === 'E1' && (calEvent.title === 'Missed Punch' || calEvent.title === 'Permission')) {

                // frappe.new_doc("Attendance Application", {
                // //    employee : calEvent.employee
                // }, doc => {
                //     doc.employee = calEvent.employee
                //     doc.date = calEvent.attendance_date
                // });

                frappe.call({
                    method: "hrms.hr.doctype.attendance_application.attendance_application.check_existing_document", // Replace 'your_app_name' with the actual name
                    args: {
                        "employee": calEvent.employee,
                        "date": calEvent.attendance_date,
                    },
                    callback: function(response) {
                        if (response.message) {
                            // Redirect to the existing document
                            frappe.set_route("Form", "Attendance Application", response.message);                        
                        } else {
                            // Create a new document
                            frappe.new_doc("Attendance Application", {}, doc => {
                                doc.employee = calEvent.employee;
                                doc.date = calEvent.attendance_date;
                            });
                        }
                    }
                });
            }
        }
	},
    get_events_method:"hrms.hr.doctype.attendance.attendance.get_events",
    filters: [
        {
            fieldname: "employee",
            label: __("Employee"),
            fieldtype: "Link",
            options: "Employee",
            get_query: function() {
                return {
                    filters: [
                        ["Employee", "user_id", "=", frappe.user.name] // Show only the logged-in user's employee record
                    ]
                };
            }
        }
    ],
    get_css_class: function(event) {
        // Define a color based on the status
        var status = event.title.toLowerCase();

        if(event.event_name == 'E1'){
            if (status === "present" || status === "on duty" || status === "work from home") {
                return "success";
            } else if (status === "absent" || status === "on leave") {
                return "danger";
            } else if (status === "missed punch") {
                return "danger";
            } else if (status === "permission") {
                return "danger";
            } else if (status === "half day") {
                return "warning";
            }
        }else{
            return "info"
        }
    }
};
