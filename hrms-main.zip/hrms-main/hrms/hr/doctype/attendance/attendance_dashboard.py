def get_data():
	return {"fieldname": "attendance", "transactions": [{"label": "", "items": ["Employee Checkin"]}]}
