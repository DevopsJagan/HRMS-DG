def get_data():
	return {
		"fieldname": "shift_request",
		"transactions": [
			{"items": ["Shift Assignment"]},
		],
	}
