Key features:

- Leave and Attendance
- Payroll
- Appraisal
- Expense Claim